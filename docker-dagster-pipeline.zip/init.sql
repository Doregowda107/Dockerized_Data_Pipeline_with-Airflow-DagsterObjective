CREATE TABLE IF NOT EXISTS stock_prices (
    date DATE NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    open NUMERIC,
    high NUMERIC,
    low NUMERIC,
    close NUMERIC,
    PRIMARY KEY (date, symbol)
);
