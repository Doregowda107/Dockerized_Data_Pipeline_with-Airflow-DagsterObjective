# Dockerized Dagster Stock Pipeline

## Overview
Dagster job that fetches daily stock data from Alpha Vantage and stores it in PostgreSQL. Docker Compose runs Postgres, Dagit (UI), and dagster-daemon (for schedules).

## Setup
1. Copy files into `docker-dagster-pipeline/` as shown.
2. Create `.env` and add your `ALPHA_VANTAGE_API_KEY`.
3. Start services:
   ```bash
   docker-compose up --build -d
   ```
4. Open Dagit: http://localhost:3000
   - The job `fetch_stock_job` will be visible.
   - Enable schedule `hourly_fetch_schedule` in the Dagit UI (Schedules → enable).

## DB
Postgres accessible at `localhost:5432` using credentials in `.env`.
Table `stock_prices(date, symbol)` is initialized automatically by `init.sql`.

## Notes
- API rate limits: Alpha Vantage free tier has limits — consider spacing runs or swapping to another API (IEX or Yahoo).
- Secrets: Keep `.env` out of version control; use Docker secrets / vault for production.
- Scaling: For production, replace dagit/dagster-daemon single containers with k8s/ECS deployment and external scheduler (or multiple workers).
