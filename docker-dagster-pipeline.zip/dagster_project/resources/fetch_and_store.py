import requests
import psycopg2
from psycopg2 import sql
from typing import Optional

def fetch_stock_data(symbol: str, api_key: str) -> Optional[dict]:
    url = (
        f"https://www.alphavantage.co/query?"
        f"function=TIME_SERIES_DAILY&symbol={symbol}&apikey={api_key}"
    )
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        if "Time Series (Daily)" not in data:
            print("Alpha Vantage response missing 'Time Series (Daily)':", data)
            return None
        latest_date, values = list(data["Time Series (Daily)"].items())[0]
        return {
            "date": latest_date,
            "open": float(values["1. open"]),
            "high": float(values["2. high"]),
            "low": float(values["3. low"]),
            "close": float(values["4. close"]),
            "symbol": symbol
        }
    except Exception as e:
        print("Error fetching stock data:", e)
        return None

def store_record_to_postgres(record: dict, host, dbname, user, password) -> bool:
    try:
        conn = psycopg2.connect(host=host, dbname=dbname, user=user, password=password)
        cur = conn.cursor()
        insert_query = sql.SQL("""
            INSERT INTO stock_prices(date, symbol, open, high, low, close)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (date, symbol) DO UPDATE
              SET open = EXCLUDED.open,
                  high = EXCLUDED.high,
                  low = EXCLUDED.low,
                  close = EXCLUDED.close;
        """)
        cur.execute(insert_query, (
            record["date"],
            record["symbol"],
            record["open"],
            record["high"],
            record["low"],
            record["close"],
        ))
        conn.commit()
        cur.close()
        conn.close()
        return True
    except Exception as e:
        print("Database error:", e)
        return False

def fetch_stock_data_and_store(symbol: str, api_key: str, db_host: str, db_name: str, db_user: str, db_pass: str):
    rec = fetch_stock_data(symbol, api_key)
    if not rec:
        print("No data fetched.")
        return None
    ok = store_record_to_postgres(rec, db_host, db_name, db_user, db_pass)
    if ok:
        return rec
    return None
