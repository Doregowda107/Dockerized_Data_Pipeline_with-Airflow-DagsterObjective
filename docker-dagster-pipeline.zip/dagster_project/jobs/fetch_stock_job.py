from dagster import (
    job,
    op,
    get_dagster_logger,
    resource,
    schedule,
    RetryPolicy,
)
import os
from resources.fetch_and_store import fetch_stock_data_and_store

LOG = get_dagster_logger()

@resource(required_resource_keys=set())
def env_resource(_):
    return {
        "api_key": os.getenv("ALPHA_VANTAGE_API_KEY"),
        "db_host": os.getenv("POSTGRES_HOST", "postgres"),
        "db_name": os.getenv("POSTGRES_DB"),
        "db_user": os.getenv("POSTGRES_USER"),
        "db_pass": os.getenv("POSTGRES_PASSWORD"),
    }

@op(required_resource_keys={"env_resource"}, retry_policy=RetryPolicy(max_retries=2, delay_seconds=30))
def fetch_and_store_op(context, symbol: str):
    env = context.resources.env_resource
    api_key = env.get("api_key")
    if not api_key:
        raise Exception("ALPHA_VANTAGE_API_KEY environment variable not set.")
    LOG.info(f"Fetching data for symbol: {symbol}")
    record = fetch_stock_data_and_store(
        symbol=symbol,
        api_key=api_key,
        db_host=env["db_host"],
        db_name=env["db_name"],
        db_user=env["db_user"],
        db_pass=env["db_pass"],
    )
    if record is None:
        raise Exception("No record fetched or stored. See logs for details.")
    LOG.info(f"Stored record for date: {record.get('date')}")

@job(resource_defs={"env_resource": env_resource})
def fetch_stock_job():
    fetch_and_store_op.alias("fetch_and_store_AAPL")("AAPL")

@schedule(job=fetch_stock_job, cron_schedule="0 * * * *", execution_timezone="UTC")
def hourly_fetch_schedule():
    return {}
