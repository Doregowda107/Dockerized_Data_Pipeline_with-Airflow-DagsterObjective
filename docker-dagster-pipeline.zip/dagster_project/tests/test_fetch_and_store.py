import pytest
from unittest.mock import patch, MagicMock
from dagster_project.resources.fetch_and_store import fetch_stock_data, store_record_to_postgres, fetch_stock_data_and_store

# Test fetch_stock_data happy path (mock requests)
@patch("dagster_project.resources.fetch_and_store.requests.get")
def test_fetch_stock_data_success(mock_get):
    mock_resp = MagicMock()
    mock_resp.raise_for_status.return_value = None
    mock_resp.json.return_value = {
        "Time Series (Daily)": {
            "2025-11-27": {
                "1. open": "100.0",
                "2. high": "110.0",
                "3. low": "90.0",
                "4. close": "105.0"
            }
        }
    }
    mock_get.return_value = mock_resp

    rec = fetch_stock_data("AAPL", "fake_key")
    assert rec is not None
    assert rec["date"] == "2025-11-27"
    assert rec["open"] == 100.0
    assert rec["close"] == 105.0

# Test fetch_stock_data handles API anomalies
@patch("dagster_project.resources.fetch_and_store.requests.get")
def test_fetch_stock_data_missing_time_series(mock_get):
    mock_resp = MagicMock()
    mock_resp.raise_for_status.return_value = None
    mock_resp.json.return_value = {"Note": "API call frequency exceeded"}
    mock_get.return_value = mock_resp

    rec = fetch_stock_data("AAPL", "fake_key")
    assert rec is None

# Test store_record_to_postgres (mock psycopg2)
@patch("dagster_project.resources.fetch_and_store.psycopg2.connect")
def test_store_record_success(mock_connect):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_conn.cursor.return_value = mock_cursor
    mock_connect.return_value = mock_conn

    record = {
        "date": "2025-11-27",
        "symbol": "AAPL",
        "open": 100.0,
        "high": 110.0,
        "low": 90.0,
        "close": 105.0
    }
    ok = store_record_to_postgres(record, "host", "db", "user", "pass")
    assert ok is True
    mock_cursor.execute.assert_called()
    mock_conn.commit.assert_called_once()
    mock_conn.close.assert_called_once()

# Integration-like test for fetch_stock_data_and_store with both mocks
@patch("dagster_project.resources.fetch_and_store.psycopg2.connect")
@patch("dagster_project.resources.fetch_and_store.requests.get")
def test_fetch_and_store_integration(mock_get, mock_connect):
    # mock API
    mock_resp = MagicMock()
    mock_resp.raise_for_status.return_value = None
    mock_resp.json.return_value = {
        "Time Series (Daily)": {
            "2025-11-27": {
                "1. open": "100.0",
                "2. high": "110.0",
                "3. low": "90.0",
                "4. close": "105.0"
            }
        }
    }
    mock_get.return_value = mock_resp

    # mock DB
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_conn.cursor.return_value = mock_cursor
    mock_connect.return_value = mock_conn

    rec = fetch_stock_data_and_store("AAPL", "fake_key", "host", "db", "user", "pass")
    assert rec is not None
    assert rec["symbol"] == "AAPL"
